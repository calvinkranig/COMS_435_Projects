

/**
 * @author calvinkranig
 * 
 * Class stores a pair of values used in a hashing function
 *
 */
public class Pair {
	protected int a,b;

	public Pair(int a, int b) {
		super();
		this.a = a;
		this.b = b;
	}
	
}
